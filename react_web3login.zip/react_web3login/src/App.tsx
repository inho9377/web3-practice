import React from 'react'
import logo from './logo.svg'
import './App.css'
import { MetaConnect } from './MetaConnect'

function App() {
  return (
    <div>
      <MetaConnect />
    </div>
  )
}

export default App
