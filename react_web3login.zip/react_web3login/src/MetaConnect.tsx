import { Web3Provider } from '@ethersproject/providers'
import { ethers } from 'ethers'
import { Provider, useCallback, useState } from 'react'

type windowEthers = {
  ethereum: any
}

export const MetaConnect = () => {
  const etherWindow = (window as unknown) as windowEthers
  const [provider, setProvider] = useState<Web3Provider | undefined>(undefined)
  const [signer, setSigner] = useState<
    ethers.providers.JsonRpcSigner | undefined
  >(undefined)

  const [walletAddress, setWalletAddress] = useState<string | undefined>(
    undefined,
  )
  const [currentBalance, setCurrentBalance] = useState<
    ethers.BigNumber | undefined
  >(undefined)
  const [currentBalanceFormat, setCurrentBalanceFormat] = useState<number>(0)
  const [chainId, setChainId] = useState<number | undefined>(undefined)

  const getProvider = async () => {
    const provider = await new ethers.providers.Web3Provider(
      etherWindow.ethereum,
    )
    setProvider(provider)

    return provider
  }

  const getSigner = async (provider: Web3Provider) => {
    await provider.send('eth_requestAccounts', [])
    const signer = provider.getSigner()
    setSigner(signer)
    return signer
  }

  const getWalletData = async (singer: ethers.providers.JsonRpcSigner) => {
    const result = await Promise.all([
      signer?.getAddress(),
      signer?.getBalance(),
      signer?.getChainId(),
    ])
    console.log(result)

    setWalletAddress(result[0])
    setCurrentBalance(result[1])
    setCurrentBalanceFormat(
      Number(ethers.utils.formatEther(result[1] as ethers.BigNumber)),
    )
    setChainId(result[2])
  }

  const connectWallet = useCallback(async () => {
    try {
      if (typeof etherWindow.ethereum !== 'undefined') {
        const _provider = await getProvider()
        const _signer = await getSigner(_provider)
        await getWalletData(_signer)
      } else {
        alert('please install metamask')
      }
    } catch (error) {
      console.log(error)
    }
  }, [])

  return (
    <>
      <button
        onClick={() => {
          connectWallet()
        }}
      >
        OnClick
      </button>
    </>
  )
}
